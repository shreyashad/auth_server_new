from django.shortcuts import render
from rest_framework.exceptions import NotFound
from rest_framework.generics import get_object_or_404

""" Added this new part for logout """
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication


# application management related views
# for all applications excluding auth server application
class ApplicationListView(generics.ListAPIView):
    queryset = Application.objects.exclude(name='Auth Server')
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]



# for creating new application
class ApplicationCreateView(generics.CreateAPIView):
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



# for retrieving update and deleting application
class ApplicationDetailView(generics.RetrieveUpdateDestroyAPIView):
    authentication_classes = [JWTAuthentication]
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


# for getting number of counts for applications
class ApplicationCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            apps = Application.objects.filter(active=True).count()
            return Response({'apps_count': apps})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ApplicationAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            application = Application.objects.get(name=request.data.get('name'))
            serializer = ApplicationSerializer(application)
            return Response({'app': serializer.data}, status=status.HTTP_200_OK)
        except Application.DoesNotExist:
            return Response({'error': 'Application not found'}, status=status.HTTP_404_NOT_FOUND)





# for Permission management related views

class PermissionListView(generics.ListAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]



class PermissionCreateView(generics.CreateAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class PermissionDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class PermissionListByApplicationView(generics.ListAPIView):
    serializer_class = PermissionSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        application_id = self.request.query_params.get('application', None)
        if application_id is None:
            return Permission.objects.none()  # Return an empty queryset if no application name is provided

        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            raise NotFound(detail="Application not found.")

        return Permission.objects.filter(application=application)


# for role management related views

class RoleListView(generics.ListAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


class RoleCreateView(generics.CreateAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class RoleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class RoleListByApplicationView(generics.ListAPIView):
    serializer_class = RoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        application_id = self.request.query_params.get('application', None)
        if application_id is None:
            return Role.objects.none()  # Return an empty queryset if no application name is provided

        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            raise NotFound(detail="Application not found.")

        return Role.objects.filter(application=application)




# for user roles assigning management related views
class UserRolesListView(generics.ListAPIView):
    serializer_class = UserRoleSerializerForDisplayList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        auth_server = Application.objects.filter(name="Auth server").first()
        if auth_server:
            # Exclude UserRole instances associated with the auth_server application
            return UserRole.objects.exclude(application=auth_server)
        return UserRole.objects.all()




class UserRoleCreateView(generics.CreateAPIView):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



class UserRoleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = UserRole.objects.all()
    serializer_class = UserRoleSerializer
    # authentication_classes = [JWTAuthentication]
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)



class UsersByApplicationAndRoleView(generics.GenericAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request, application_name, role_name):
        # Get the application instance
        application = get_object_or_404(Application, name=application_name)

        # Get the role instance
        role = get_object_or_404(Role, name=role_name, application=application)

        # Get the users associated with the specified role for the application
        user_roles = UserRole.objects.filter(application=application, role=role).select_related('user')

        # Serialize the user data
        users = [user_role.user for user_role in user_roles]
        serializer = self.get_serializer(users, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)



# for Auth Server User Role
class AuthServerUserRolesListView(generics.ListAPIView):
    serializer_class = UserRoleSerializerForDisplayList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        auth_server = Application.objects.filter(name="Auth server").first()
        if auth_server:
            # Exclude UserRole instances associated with the auth_server application
            return UserRole.objects.filter(application=auth_server)
        return UserRole.objects.all()


class AssignAuthServerUserRoleView(generics.CreateAPIView):
    serializer_class = AssignRolesAuthServerSerializers
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return UserRole.objects.filter(application__name='auth_server')

    def post(self, request, *args, **kwargs):
        # Validate if role is among the allowed roles for 'auth_server'
        allowed_roles = ['Administrator', 'Authenticator', 'Site Admin']
        role = request.data.get('role')

        if role not in allowed_roles:
            return Response({'error': 'Invalid role assigned.'}, status=status.HTTP_400_BAD_REQUEST)

        return super().post(request, *args, **kwargs)