from django.urls import path
from .views import *

urlpatterns = [

    path('applications-list/', ApplicationListView.as_view(), name='application-list'),
    path('create-applications/', ApplicationCreateView.as_view(), name='application-create'),
    path('applications/<uuid:pk>/details/', ApplicationDetailView.as_view(), name='application-detail'),
    path('application-count/', ApplicationCountView.as_view(), name='application-count'),
    path('application-details/', ApplicationAPIView.as_view(),name='application'),
    # Permission URLs
    path('permissions-list/', PermissionListView.as_view(), name='permission-list'),
    path('create-permissions/', PermissionCreateView.as_view(), name='permission-create'),
    path('permissions/<uuid:pk>/details/', PermissionDetailView.as_view(), name='permission-detail'),
    path('permissions/by-application/', PermissionListByApplicationView.as_view(), name='permission-by-application'),

    # Role URLs
    path('roles-list/', RoleListView.as_view(), name='role-list'),
    path('create-roles/', RoleCreateView.as_view(), name='role-create'),
    path('roles/<uuid:pk>/details/', RoleDetailView.as_view(), name='role-detail'),
    path('roles/by-application/', RoleListByApplicationView.as_view(), name='roles-by-application'),

    # UserRole URLs
    path('user-roles-list/', UserRolesListView.as_view(), name='user-role-list'),
    path('assign-user-roles/', UserRoleCreateView.as_view(), name='user-role-create'),
    path('user-roles/<uuid:pk>/details/', UserRoleDetailView.as_view(), name='userrole-detail'),
    path('users/<str:application_name>/<str:role_name>/by-apps/', UsersByApplicationAndRoleView.as_view(), name='users_by_application_and_role'),
    path('auth-server-user-roles-list/', AuthServerUserRolesListView.as_view(), name='auth-server-user-role-list'),
    path('assign-auth-server-user-roles/', AssignAuthServerUserRoleView.as_view(), name='create-auth-server-role'),


]
