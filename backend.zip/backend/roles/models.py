from django.db import models
from accounts.models import BaseModel, CustomUser
import uuid
# Create your models here.

class Application(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    base_url = models.URLField(blank=True, null=True, help_text="Base URL for the application")
    active = models.BooleanField(default=True, help_text="Is the application active?")


    def __str__(self):
        return self.name



class Permission(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    can_create = models.BooleanField(default=False)
    can_read = models.BooleanField(default=True)
    can_update = models.BooleanField(default=False)
    can_delete = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'Permission'
        verbose_name_plural = 'Permissions'
        unique_together = ['name', 'application']

    def __str__(self):
        return f'{self.name} ({self.application})'


class Role(BaseModel):
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    permissions = models.ManyToManyField(Permission)
    default_for_application = models.BooleanField(default=False, help_text="Is this the default role for the application?")


    class Meta:
        verbose_name = 'Role'
        verbose_name_plural = 'Roles'
        unique_together = ['name', 'application']

    def __str__(self):
        return f'{self.name} ({self.application})'

    def save(self, *args, **kwargs):
        """
        Ensure only one default role exists per application.
        """
        if self.default_for_application:
            # Ensure no other role for the same application is set as default
            Role.objects.filter(application=self.application, default_for_application=True).update(
                default_for_application=False)
        super().save(*args, **kwargs)


class UserRole(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('user', 'role', 'application')

    def get_absolute_url(self):
        if self.application.base_url:
            return f"{self.application.base_url}/user/{self.user.username}"
        else:
            return "/profile/"

    def __str__(self):
        return f"{self.user.username} - {self.role.name} - {self.application.name}"

    @classmethod
    def assign_role(cls, user, application, role=None):
        """
        Assign a role to a user for an application.
        If no role is provided, assign the default role for the application.
        """
        if not role:
            # If no role is provided, get the default role for the application
            role = Role.objects.filter(application=application, default_for_application=True).first()

        if not role:
            raise ValueError(f"No default role set for application {application.name} and no role provided.")

        # Create or get the UserRole
        user_role, created = cls.objects.get_or_create(user=user, role=role, application=application)

        return user_role


class SiteAdminFilterSettings(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)  # Use SET_NULL for better flexibility
    application = models.ForeignKey(Application, on_delete=models.CASCADE)  # Consider cascading delete if needed

    class Meta:
        verbose_name = 'Site Admin Filter Settings'  # Updated verbose name
        verbose_name_plural = 'Site Admin Filter Settings'  # Updated verbose name plural

    def __str__(self):
        return f'{self.user.username} Filter Settings' if self.user else 'Filter Settings without User'
