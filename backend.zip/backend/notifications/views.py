from django.shortcuts import get_object_or_404
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.authentication import JWTAuthentication

# for Notification list as per applications
class NotificationListView(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def get_queryset(self):
        user = self.request.user
        application_name = self.request.query_params.get('application_name')  # Get application name from query parameters

        # Base queryset: notifications for the authenticated user
        queryset = Notification.objects.filter(user=user)

        # Fetch the application ID based on the application name
        if application_name:
            application = get_object_or_404(Application, name=application_name)  # Assuming your Application model has a 'name' field
            queryset = queryset.filter(application_id=application.id)

        return queryset



class NotificationCreateView(generics.CreateAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def perform_create(self, serializer):
        user = self.request.user
        application_id = self.request.data.get('application_id')

        # Check if the application exists
        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            return Response({"detail": "Application not found."}, status=status.HTTP_404_NOT_FOUND)

        # Create the notification with the authenticated user and the application
        notification = serializer.save(user=user, application=application)

        return Response(NotificationSerializer(notification).data, status=status.HTTP_201_CREATED)

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return self.perform_create(serializer)


class NotificationDetailView(generics.RetrieveAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def get_queryset(self):
        user = self.request.user
        return super().get_queryset().filter(user=user)


class NotificationUpdateView(generics.UpdateAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def get_queryset(self):
        user = self.request.user
        return super().get_queryset().filter(user=user)

    def perform_update(self, serializer):
       serializer.save()


class NotificationDeleteView(generics.DestroyAPIView):
    queryset = Notification.objects.all()
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def get_queryset(self):
        user = self.request.user
        return super().get_queryset().filter(user=user)




class MarkNotificationAsReadView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]

    def post(self, request, pk):
        try:
            notification = Notification.objects.get(id=pk, user= request.user)
        except Notification.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)

        notification.mark_as_read()
        return Response({'status': 'Notification marked as read'}, status=status.HTTP_200_OK)

