from django.db import models
from django.utils import timezone
from django.conf import settings
from roles.models import Application
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
# Create your models here.

class NotificationType(models.TextChoices):
    INFO = 'info', 'Info'
    WARNING = 'warning', 'Warning'
    ALERT = 'alert', 'Alert'
    SUCCESS = 'success', 'Success'


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=255)
    message = models.TextField()
    notification_type = models.CharField(max_length=10, choices=NotificationType.choices, default=NotificationType.INFO)
    created_at = models.DateTimeField(default=timezone.now)
    read = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.application.name} Notification'

    def mark_as_read(self):
        self.read = True
        self.save()

    def save(self, *args, **kwargs):
        created = not self.pk
        super().save(*args, **kwargs)

        if created:
            channel_layer = get_channel_layer()
            async_to_sync(channel_layer.group_send)(
                f"user_{self.user.id}",
                {
                    "type": "send_notification",
                    "title": self.title,
                    "message": self.message,
                    "notification_type": self.notification_type,
                    "created_at": self.created_at.isoformat(),
                    "application": self.application.name
                }
            )