from django.urls import path
from .views import *

urlpatterns = [
    path('audit-logs-list', AuditLogListView.as_view(), name='audit-list'),
    path('audit/<uuid:pk>/details', AuditLogDetailView.as_view(), name='audit-details'),
    path('user-application-status-chart/', UserApplicationStatusChartView.as_view(),
         name='user_application_status_chart'),
path('online-users-by-application/', OnlineUsersByApplicationView.as_view(), name='online-users'),
]