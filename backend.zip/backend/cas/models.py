from django.db import models, transaction
from accounts.models import CustomUser
from roles.models import Application
import random
import string
from django.utils import timezone
import secrets


class TicketManager(models.Manager):
    def create_ticket(self, user, application, **kwargs):
        with transaction.atomic():
            ticket = self.create_ticket_str()
            expires = timezone.now() + timezone.timedelta(minutes=self.model.TICKET_EXPIRE)
            return self.create(ticket=ticket, user=user, application=application, expires=expires, **kwargs)

    def create_ticket_str(self, prefix=None):
        if not prefix:
            prefix = self.model.TICKET_PREFIX
        return f"{prefix}-{int(timezone.now().timestamp())}-{''.join(random.choices(string.ascii_uppercase + string.digits, k=self.model.TICKET_RAND_LEN))}"

    def validate_ticket(self, ticket, application):
        try:
            t = self.get(ticket=ticket)
        except self.model.DoesNotExist:
            raise ValueError("Invalid ticket")
        if t.is_consumed:
            raise ValueError("Ticket already consumed")
        if t.is_expired:
            raise ValueError("Ticket expired")
        if t.application != application:
            raise ValueError("Invalid application")
        return t


class Ticket(models.Model):
    TICKET_EXPIRE = 90  # Default expiration in minutes
    TICKET_RAND_LEN = 32
    TICKET_PREFIX = 'T'

    ticket = models.CharField(max_length=255, unique=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    expires = models.DateTimeField()
    consumed = models.DateTimeField(null=True, blank=True)

    objects = TicketManager()

    @property
    def is_expired(self):
        return timezone.now() > self.expires

    @property
    def is_consumed(self):
        return self.consumed is not None

    def consume(self):
        self.consumed = timezone.now()
        self.save()

    @classmethod
    def create_ticket_str(cls, prefix=None):
        if not prefix:
            prefix = cls.TICKET_PREFIX
        return f"{prefix}-{int(timezone.now().timestamp())}-{''.join(random.choices(string.ascii_uppercase + string.digits, k=cls.TICKET_RAND_LEN))}"

    @classmethod
    def create_ticket(cls, user, application):
        with transaction.atomic():
            ticket_str = cls.create_ticket_str()
            expires = timezone.now() + timezone.timedelta(minutes=cls.TICKET_EXPIRE)
            return cls.objects.create(ticket=ticket_str, user=user, application=application, expires=expires)

    @classmethod
    def validate_ticket(cls, ticket, application):
        try:
            t = cls.objects.get(ticket=ticket)
        except cls.DoesNotExist:
            raise ValueError("Invalid ticket")
        if t.is_consumed:
            raise ValueError("Ticket already consumed")
        if t.is_expired:
            raise ValueError("Ticket expired")
        if t.application != application:
            raise ValueError("Invalid application")
        return t


class ServiceTicket(Ticket):
    TICKET_PREFIX = 'ST'

    primary = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"


class ProxyTicket(Ticket):
    TICKET_PREFIX = 'PT'

    granted_by_pgt = models.ForeignKey('ProxyGrantingTicket', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"


class ProxyGrantingTicket(Ticket):
    TICKET_PREFIX = 'PGT'
    IOU_PREFIX = 'PGTIOU'

    iou = models.CharField(max_length=255, unique=True)
    granted_by_st = models.ForeignKey('ServiceTicket', null=True, blank=True, on_delete=models.PROTECT)
    granted_by_pt = models.ForeignKey('ProxyTicket', null=True, blank=True, on_delete=models.PROTECT)

    def __str__(self):
        return f"{self.TICKET_PREFIX}-{self.ticket}"

    def save(self, *args, **kwargs):
        if not self.iou:
            self.iou = self.generate_unique_iou()
        super().save(*args, **kwargs)

    def generate_unique_iou(self):
        while True:
            iou = f"{self.IOU_PREFIX}-{secrets.token_urlsafe(16)}"
            if not ProxyGrantingTicket.objects.filter(iou=iou).exists():
                return iou




class UserSession(models.Model):
    TICKET_EXPIRE = 60

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    session_key = models.CharField(max_length=255, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_accessed = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    # Static method to generate session key
    @staticmethod
    def create_ticket_str():
        return secrets.token_urlsafe(32)  # Generates a secure random string for session key

    def is_expired(self):
        return timezone.now() > self.expires_at

    def expire(self):
        self.is_active = False
        self.save()

    def __str__(self):
        return f"Session {self.session_key} for user {self.user.username}"
