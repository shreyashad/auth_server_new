from django.contrib import admin
from .models import *
# Register your models here.



@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ["ticket","user","application", "expires","consumed"]


@admin.register(ServiceTicket)
class ServiceTicketAdmin(admin.ModelAdmin):
    list_display = ['primary']



@admin.register(ProxyGrantingTicket)
class ProxyGrantingTicketAdmin(admin.ModelAdmin):
    list_display = ['iou', 'granted_by_st', 'granted_by_pt']



@admin.register(UserSession)
class UserSessionAdmin(admin.ModelAdmin):
    list_display = ['user', 'application', 'expires_at']




