from rest_framework import serializers
from .models import Team, TeamMembership, TeamInvite, TeamNotification

class TeamSerializerList(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()
    created_by_username = serializers.SerializerMethodField()
    updated_by_username = serializers.SerializerMethodField()

    class Meta:
        model = Team
        fields = ['id', 'created_at', 'updated_at', 'name', 'description', 'created_by', 'updated_by', 'users', 'created_by_username', 'updated_by_username']

    def get_users(self, obj):
        return [user.username for user in obj.users.all()]

    def get_created_by_username(self, obj):
        return obj.created_by.username if obj.created_by else None

    def get_updated_by_username(self, obj):
        return obj.updated_by.username if obj.updated_by else None


class TeamSerializer(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()
    class Meta:
        model = Team
        fields = ['id','name', 'description','users','created_at', 'updated_at', 'created_by', 'updated_by',]
    def get_users(self, obj):
        return [user.id for user in obj.users.all()]

class TeamMembershipSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamMembership
        fields = '__all__'

class TeamInviteSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamInvite
        fields = '__all__'

class TeamNotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeamNotification
        fields = '__all__'
